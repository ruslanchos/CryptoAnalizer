package ru.javarush.sheff.cryptoanalyzer.entity;

public enum ResultCode {
    OK,ERROR
}
